/*
    Escribe una función que reciba un número como parámetro y retorne
    "fizz" si el número es divisible por 3, "buzz" si es divisible por 5
    o "fizzbuzz" si es divisible por ambos.
*/

function fizzBuzz(n) {
  // Codigo
}

console.log(fizzBuzz(12))
console.log(fizzBuzz(25))
console.log(fizzBuzz(15))